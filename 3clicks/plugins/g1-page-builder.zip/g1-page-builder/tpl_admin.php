<div class="wrap">
    <h2><?php echo __( 'G1 Page Builder', 'g1_theme' ); ?></h2>
</div>

